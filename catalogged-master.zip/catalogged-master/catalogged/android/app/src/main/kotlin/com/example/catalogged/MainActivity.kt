package com.example.catalogged

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
