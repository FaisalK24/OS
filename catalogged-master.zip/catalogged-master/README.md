# CataLogged

A mobile application for managing receipts and return dates

Made with Flutter.io and uses Firebase backend


